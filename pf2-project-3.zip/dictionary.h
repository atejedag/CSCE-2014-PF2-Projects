#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// set size of array
const int SIZE = 1000;
class dictionary
{
public:
    dictionary();
    ~dictionary();
    
    void read_file(string fileName);
    string binary_search(string word, int low, int high);
    string toLowerCase(string word1);
    bool isName(string word1, string prevWord);

private:
    string wordArray[SIZE];
    int rankArray[SIZE];
    int count;
    
};