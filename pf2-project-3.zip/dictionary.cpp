#include "dictionary.h"

// construcc
dictionary::dictionary()
{
    // fill word array with blanks
    count = 0;
    for (int i = 0; i < SIZE; i++)
        wordArray[i] = "";
}

// destrucc
dictionary::~dictionary()
{
    
}

//------------------------------------------------------------------

// methods
void dictionary::read_file(string fileName) // adapted from dictionary.cpp source code by JGauch
{
    // open
    ifstream din;
    din.open(fileName.c_str());
    if (din.fail())
        return;
        
    // read file
    count = 0;
    int num;
    string str;
    while (!din.eof() && count < SIZE)
    {
        din >> num >> str; // reads rank and word
        wordArray[count] = str; // sets word to current array count
        rankArray[count] = num; // sets rank number to current array thing
        count++; // incrent count + 1 
        
    }
    din.close();
}

// format referenced from numbers2.cpp 
string dictionary::binary_search(string word, int low, int high)
{
    int mid = (low + high) / 2; // find midpoint
    
    // terminating condition
    if (low > high)
    {
        return "";
    }
    else if (wordArray[mid] == word)
    {
        return word;
    }
    // recursive cases
    else if (wordArray[mid] > word)
        return binary_search(word, low, mid - 1);
        
    else
        return binary_search(word, mid + 1, high);
}

// returns word in all lowercase and removes any punctuation/non-letters
string dictionary::toLowerCase(string word1)
{
    string word2 = "";
    for (int i = 0; i < word1.length(); i++)
    {
        if (isupper(word1[i]))              // if letter is uppercase, make it lowercase
            word1[i]= (tolower(word1[i]));
        
        if (isalpha(word1[i]))              // seperate letters from any non-letters into new string
            word2 = word2 + word1[i];
    }
    return word2;
}

// detect if word is a name
bool dictionary::isName(string word1, string prevWord)
{
    if ((prevWord[prevWord.length() - 1] != '.') || (prevWord == "Mrs.") || (prevWord == "Mr.")) // last character of last word is NOT a period, (aka not start of sentence) then it is a name
        return true;
    else
        return false;
}



