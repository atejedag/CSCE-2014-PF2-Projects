#include <iostream>
#include "dictionary.h"
using namespace std;

int main()
{
    // set up class
    dictionary dictionaryWords; 
    dictionaryWords.read_file("top1000.txt"); 
    
    // VARIABLES TO SET FILENAMES TO USE
    string bookFile = "book1.txt";          // TO READ
    string abridgedFile = "abridged1.txt";  // TO WRITE
    
    // variables reading words
    string word;
    string prevWord = "";
    
    ifstream din;
    din.open(bookFile);
    if (din.fail())
        return 0;
        
    ofstream don;
    don.open(abridgedFile);
    if (don.fail())
        return 0;

    // declare count to increment every time a word is added so every 15 words or so it will add a new line.
    int count = 0; 
    while (!din.eof())
    {
        count++; // increment count for new lines every couple of words to make output file nicer 
        din >> word; // reads word
        
        
        string wordToFind = dictionaryWords.toLowerCase(word);  // Save a lowercased word w/out punctuation
        string wordFound = dictionaryWords.binary_search(wordToFind, 0, 999);   // search array with new formatted word and will save the same word if found
        
        if (wordFound == wordToFind) // if word is in top1000, add to file
            don << word << " ";
        
        else if (isupper(word[0])) // is first letter of word capital
        {
            if (dictionaryWords.isName(word, prevWord)) // method to find if word is possibly a name
                don << word << " ";
        }
        
        if (count % 15 == 0) // every 15 words, add a new line
            don << endl;
        
        prevWord = word; // save previous word to help with finding names
    }
    din.close();
    don.close();

    return 0;
}
