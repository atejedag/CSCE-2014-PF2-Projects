//-----------------------------------------------------------
//  Purpose:    Header file for review database class.
//  Author:     John Gauch
//-----------------------------------------------------------

#include "ReviewNode.h"

#ifndef REVIEW_DB_H
#define REVIEW_DB_H

class ReviewDB
{
public:
   ReviewDB();
   ReviewDB(const ReviewDB & db);
   ~ReviewDB();

   void insertReview();
   void printRestaurant();
   void printCategory();
   void printRecent();

private:
   ReviewNode *Head;
   int count;
};

#endif
