//-----------------------------------------------------------
//  Purpose:    Implementation of the restaurant review class.
//  Author:     John Gauch
//-----------------------------------------------------------

#include "ReviewNode.h"

ReviewNode::ReviewNode()
{
   Customer = "none";
   Restaurant = "none";
   Category = "none";
   DeliveryCost = 0.0;
   TimeRating = 0;
   FoodRating = 0;
   OverallRating = 0;
   Next = NULL;
}

ReviewNode::ReviewNode(const ReviewNode & reviewnode)
{
   Customer = reviewnode.Customer;
   Restaurant = reviewnode.Restaurant;
   Category = reviewnode.Category;
   DeliveryCost = reviewnode.DeliveryCost;
   TimeRating = reviewnode.TimeRating;
   FoodRating = reviewnode.FoodRating;
   OverallRating = reviewnode.OverallRating;
   Next = NULL;
}

ReviewNode::ReviewNode(string customer, string restaurant, string category, 
      float cost, int time, int food, int overall)
{
   Customer = customer;
   Restaurant = restaurant;
   Category = category;
   DeliveryCost = cost;
   TimeRating = time;
   FoodRating = food;
   OverallRating = overall;
   Next = NULL;
}

ReviewNode::~ReviewNode()
{
}

string ReviewNode::getCustomer()
{
   return Customer;
}

string ReviewNode::getRestaurant()
{
   return Restaurant;
}

string ReviewNode::getCategory()
{
   return Category;
}

float ReviewNode::getDeliveryCost()
{
   return DeliveryCost;
}

int ReviewNode::getTimeRating()
{
   return TimeRating;
}

int ReviewNode::getFoodRating()
{
   return FoodRating;
}

int ReviewNode::getOverallRating()
{
   return OverallRating;
}

bool ReviewNode::setCustomer(string customer)
{
   Customer = customer;
   return true;
}

bool ReviewNode::setRestaurant(string restaurant)
{
   Restaurant = restaurant;
   return true;
}

bool ReviewNode::setCategory(string category)
{
   Category = category;
   return true;
}

bool ReviewNode::setDeliveryCost(float cost)
{
   // Check cost is greater than zero
   if (cost < 0) return false;
   DeliveryCost = cost;
   return true;
}

bool ReviewNode::setTimeRating(int time)
{
   // Check rating is between [1..10]
   if (time < 1 || time > 10) return false;
   TimeRating = time;
   return true;
}

bool ReviewNode::setFoodRating(int food)
{
   // Check rating is between [1..10]
   if (food < 1 || food > 10) return false;
   FoodRating = food;
   return true;
}

bool ReviewNode::setOverallRating(int overall)
{
   // Check rating is between [1..10]
   if (overall < 1 || overall > 10) return false;
   OverallRating = overall;
   return true;
}

void ReviewNode::read()
{
   cout << "Enter customer name: ";
   cin >> Customer;
   cout << Customer << endl;

   cout << "Enter restaurant name: ";
   cin >> Restaurant;
   cout << Restaurant << endl;
   
   cout << "Enter restaurnant category: ";
   cin >> Category;
   cout << Category << endl;

   do {
      cout << "Enter delivery cost: ";
      cin >> DeliveryCost;
      cout << DeliveryCost << endl;
   } while (DeliveryCost < 0);

   do {
      cout << "Enter delivery time rating [1..10]: ";
      cin >> TimeRating;
      cout << TimeRating << endl;
   } while (TimeRating < 1 || TimeRating > 10);

   do {
      cout << "Enter food rating [1..10]: ";
      cin >> FoodRating;
      cout << FoodRating << endl;
   } while (FoodRating < 1 || FoodRating > 10);

   do {
      cout << "Enter overall rating [1..10]: ";
      cin >> OverallRating;
      cout << OverallRating << endl;
   } while (OverallRating < 1 || OverallRating > 10);
}

void ReviewNode::print()
{
   cout << endl;
   cout << "Customer name:        " << Customer << endl;
   cout << "Restaurant name:      " << Restaurant << endl;
   cout << "Restaurant category:  " << Category << endl;
   cout << "Delivery Cost:        " << DeliveryCost << endl;
   cout << "Delivery time rating: " << TimeRating << endl;
   cout << "Food rating:          " << FoodRating << endl;
   cout << "Overall rating:       " << OverallRating << endl;
   cout << endl;
}

ReviewNode *ReviewNode::getNext()
{
    return Next;
}

void ReviewNode::setNext(ReviewNode * next)
{
    Next = next;
}







