//-----------------------------------------------------------
//  Purpose:    Header file for the restaurant review class.
//  Author:     John Gauch
//-----------------------------------------------------------

#include <iostream>
using namespace std;

#ifndef REVIEW_H
#define REVIEW_H

class ReviewNode 
{
public:
   ReviewNode();
   ReviewNode(const ReviewNode & reviewnode);
   ReviewNode(string customer, string restaurant, string category, 
      float cost, int time, int food, int overall);
   ~ReviewNode();

   string getCustomer();
   string getRestaurant();
   string getCategory();
   float getDeliveryCost();
   int getTimeRating();
   int getFoodRating();
   int getOverallRating();

   bool setCustomer(string customer);
   bool setRestaurant(string restaurant);
   bool setCategory(string category);
   bool setDeliveryCost(float cost);
   bool setTimeRating(int time);
   bool setFoodRating(int food);
   bool setOverallRating(int overall);

   void read();
   void print();
   
   void setNext(ReviewNode * next);
   ReviewNode *getNext();

private:
   string Customer;
   string Restaurant;
   string Category;
   float DeliveryCost;
   int TimeRating;
   int FoodRating;
   int OverallRating;
   ReviewNode *Next;
};

#endif