//-----------------------------------------------------------
//  Purpose:    Implementation of review database class.
//  Author:     John Gauch
//-----------------------------------------------------------

#include "ReviewDB.h"

ReviewDB::ReviewDB()
{
    count = 0;
    Head = NULL;
}

ReviewDB::ReviewDB(const ReviewDB & db)
{
    ReviewNode *ptrCopy = new ReviewNode();
    Head = ptrCopy;
   
    // Go though all nodes and copies them, Template from Dr. Gauch's source code "student_list" class
    ReviewNode *ptr = db.Head;
    while (ptr != NULL)
    {
        ptrCopy->setNext(new ReviewNode());
        ptrCopy = ptrCopy->getNext();
        ptrCopy->setCustomer(ptr->getCustomer());
        ptrCopy->setRestaurant(ptr->getRestaurant());
        ptrCopy->setCategory(ptr->getCategory());
        ptrCopy->setDeliveryCost(ptr->getDeliveryCost());
        ptrCopy->setTimeRating(ptr->getTimeRating());
        ptrCopy->setFoodRating(ptr->getFoodRating());
        ptrCopy->setOverallRating(ptr->getOverallRating());
        ptrCopy->setNext(NULL);
        ptr = ptr->getNext();
    }
   // tidy up
    ptrCopy = Head;
    Head = ptrCopy->getNext();
    delete ptrCopy;
}

ReviewDB::~ReviewDB()
{
   
}

void ReviewDB::insertReview() // Insert review at head and add +1 to count
{
    // initialize variables
    string customer;
    string restaurant;
    string category;
    float deliveryCost;
    int timeRating;
    int foodRating;
    int overallRating; 
    
    
    // get inputs for each variable   
    cout << "\nEnter the name of the customer: ";
    cin >> customer;
   
    cout << "\nEnter the name of the restaurnt: ";
    cin >> restaurant;
   
    cout << "\nEnter the category: ";
    cin >> category;
   
    cout << "\nEnter the  devlivery cost: ";
    cin >> deliveryCost;
   
    cout << "\nEnter the time rating: ";
    cin >> timeRating;
   
    cout << "\nEnter the food rating: ";
    cin >> foodRating;
   
    cout << "\nEnter the overall rating: ";
    cin >> overallRating;
    
    // insert reviewnode into linked list
    ReviewNode *ptr = new ReviewNode(customer, restaurant, category, deliveryCost, timeRating, foodRating, overallRating);
    ptr->setNext(Head);
    Head = ptr;
    
    // print out amount of reviews in list
    count = count + 1;
    cout << "\nThere is " << count << " review(s) in database\n";
}

void ReviewDB::printRestaurant() // prints all customer reviews for a specified restaurant
{
    string restaurantToFind; // store input
    string currentRestaurant; // store restaurant in current node
    bool reviewFound = false; // check if there's at least 1 review found
    
    // get input
    cout << "\nEnter name of restaurant to search reviews for: ";
    cin >> restaurantToFind;
    
    // while loop to go through the list to find matching restaurant reviews
    ReviewNode *ptr = Head;
    while (ptr != NULL)
    {
        currentRestaurant = ptr->getRestaurant();
        if (restaurantToFind == currentRestaurant) // compare
        {
            ptr->print(); 
            reviewFound = true;
        }
        ptr = ptr->getNext(); // goes to next node
    }
    // if no reviews are found, print out this
    if (reviewFound == false) 
        cout << "No reviews found under '" << restaurantToFind << "'" << endl;
}

void ReviewDB::printCategory() // prints all customer reviews for a specified food category.
{
    // Note: has same format as printRestaurant method
    string categoryToFind; // store input
    string currentCategory; // store current node's category
    bool reviewFound = false; // check if at least 1 review is found
    
    // get input
    cout << "\nEnter name of category to search reviews for: ";
    cin >> categoryToFind;
    
    // while loop that goes through entire linked list
    ReviewNode *ptr = Head;
    while (ptr != NULL)
    {
        currentCategory = ptr->getCategory();
        if (categoryToFind == currentCategory)
        {
            ptr->print();
            reviewFound = true; 
        }
        ptr = ptr->getNext();
    }
    if (reviewFound == false) 
        cout << "\nNo reviews found under '" << categoryToFind << "'" << endl;
}

void ReviewDB::printRecent()
{
    // prints the N most recent customer reviews
    int N;
    do
    {
        cout << "Total Reviews in database: " << count << endl;
        cout << "N must be greater than 0 and no more than the total amount of reviews" << endl;
        cout << "Enter the N most recent reviews you want to print out: ";
        cin >> N;
    }
    while ((N > count)||(N < 1)); // if out of range, ask for input again
    
    // for loop to print out N reviews 
    ReviewNode *ptr = Head;
    for (int i = 0; i < N; i++)
    {
        ptr->print();
        ptr = ptr->getNext();
    }
}
