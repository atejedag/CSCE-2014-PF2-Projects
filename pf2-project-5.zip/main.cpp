#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;

//------------------------------------------------------------------
// Read a single word from din
//------------------------------------------------------------------
bool read_word(string & word, ifstream & din)
{
    // Initialize variables
    word = "";
    bool found_word = false;

    // Loop reading characters until word is found
    while (!din.fail() && !din.eof() && !found_word)
    {
        // Read next character from file
        char ch;
        din.get(ch);

        // Append lower case letter to word
        if (ch >= 'a' && ch <= 'z')
	    word = word + ch;

        // Convert upper case letter to lower case and append
        else if (ch >= 'A' && ch <= 'Z')
	    word = word + char(ch - 'A' + 'a');

        // Return word if length greater than zero
        else if (word.length() > 0)
	    found_word = true;
    }

    // Return boolean flag
    return found_word;
}



void merge_sort2(string data[], string copy[], int low, int high)
{
    // Check terminating condition
    int range = high - low + 1;
    if (range > 1)
    {
        // Divide the array and sort both halves
        int mid = (low + high) / 2;
        merge_sort2(data, copy, low, mid);
        merge_sort2(data, copy, mid + 1, high);

        // Initialize array indices
        int index1 = low;
        int index2 = mid + 1;
        int index = 0;

        // Merge smallest data elements into copy array
        while (index1 <= mid && index2 <= high)
        {
	        if (data[index1] < data[index2])
	            copy[index++] = data[index1++];
	        else
	            copy[index++] = data[index2++];
        }

        // Copy any remaining entries from the first half
        while (index1 <= mid)
	    copy[index++] = data[index1++];

        // Copy any remaining entries from the second half
        while (index2 <= high)
	    copy[index++] = data[index2++];

        // Copy data back from the temporary array
        for (index = 0; index < range; index++)
	    data[low + index] = copy[index];
    }
}



// CURRENT VERSION: READS FILE AND SAVES EACH 2 WORDS IN ARRAY
// TO DO: include merge sort and test, 
//        count top 10 most frequent 2 word combinations and test
int main()
{
    // get size of array
    const int SIZE = 10000; // size of array
    cout << "Note: Array size is 10,000, if it goes over the limit, program closes" << endl;
    
    // get filename
    string fileName;
    cout << endl << "Input Name of file w/file type (ex: .txt): ";
    cin >> fileName;
    cout << endl;
    
    string array[SIZE];
    
    
    ifstream din;
    din.open(fileName);
    if (din.fail()) return -1;
    
    int count = 0;
    string word;
    string previousWord = "";
    
    
    // start reading before loop to get it started
    read_word(word, din); 
    array[count] = word; 
    read_word(word, din); 
    array[count] = array[count] + " " + word; // ex: array0 = I + AM
    previousWord = word; // save current word
    count++; // increment count
    
    while (read_word(word, din))
    {
        array[count] = previousWord + " " + word; // array1 = AM + SAM
        count++; // go on to next 2 word combination to save to array
        previousWord = word; // save word in previousword for next iteration
        
        if (count >= SIZE)
        {
            cout << "No more space in array, stopping..." << endl;
            din.close();
            return 0;
        }
    }
    
    // declare new array, merge sort copies sorted version of array
    string sortedArray[SIZE];
    merge_sort2(array, sortedArray, 0, count);
    
    
    // setup for saving phrases and how many of each phrase
    string phrasesArray[count+1];
    int frequencyArray[count+1];
    int tempCount = 0; //track current place for phrases and frequency arrays
    
    // stuff to do to start the look through the array
    string tempPhrase = sortedArray[0];
    phrasesArray[0] = tempPhrase;
    int freqCount = 0;
    for (int i = 1; i <= count; i++) // go through rows
    {
        if (tempPhrase == sortedArray[i]) // adds 1 to frequency count
        {
            freqCount = freqCount + 1;
        }
        else if (tempPhrase != sortedArray[i]) // if new word is found, save count of old word and save new word into temp
        {
            frequencyArray[tempCount] = freqCount;
            tempCount++;
            phrasesArray[tempCount] = sortedArray[i];
            tempPhrase = sortedArray[i];
            freqCount = 1;
        }
    }
    
    // start outputing things to file
    ofstream dout;
    dout.open("output.txt");

    for (int i = 0; i < tempCount-1; i++)
    {
        int max = 0;
        int maxLocation;
        for (int i = 0; i <= tempCount-1; i++) // w/out -1, it prints out last phrase again with 0 count.
        {
            if (frequencyArray[i] > max)
            {
                max = frequencyArray[i];
                maxLocation = i;
            }
        }
        frequencyArray[maxLocation] = -1; // set to -1 so it doesnt choose that phrase again
        dout << max << " " << phrasesArray[maxLocation] << endl;
    }
    
    

    dout.close();
    din.close();
    
    return 0;
}
