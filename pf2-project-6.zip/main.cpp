#include <iostream>
#include <fstream>
#include "tree.h"
using namespace std;


// Notes: Binary tree class from source code on website
//        Probably need to change some things (also test more)
//        and then implement the rest of the project

// read from file, specifically only in format from the original address.txt
void Read(string fileName, BinaryTree& tree)
{
    ifstream din;
    din.open(fileName);
    
    string houseNum;
    string street;
    string city;
    string state;
    string zip;
    string blank;
    
    while (!din.eof())
    {
        getline(din, houseNum);
        getline(din, street);
        getline(din, city);
        getline(din, state);
        getline(din, zip);
        getline(din, blank); // "reads" over blank line just so then it goes to the next line for next loop
        
        // combined city and street for the key and then combine everthing for the full address
        string key = city + " " + street;
        string address = houseNum + " " + street  + " " +  city  + " " + state  + " " +  zip;
        
        // call method to insert
        tree.Insert(key, address);
    }
    
    //close file at the end
    din.close();
}

void Write(string fileName, BinaryTree tree) // print tree to file
{
    // open ofstream and then call method to print to sorted address file
    ofstream dout;
    dout.open(fileName);
    tree.Print(dout);
    dout.close();
}


int main()
{
    // declare object and hard coded file names
    BinaryTree Tree;
    string file = "address.txt";
    string sortedFile = "sorted_address.txt";
    
    // intial read of address.txt file
    Read(file, Tree);
    
    // main while loop, will break if input is anything except 1,2,3 when selecting what to do
    while (true)
    {
        // main output for instructions using integers, non integers will cause errors
        cout << "Type the corresponding Number to choose the function\n";
        cout << "[1] Insert new address into the Tree\n" 
             << "[2] Search for and output full address given city and street name\n"
             << "[3] Find height\n"
             << "[0/Other] Quit\n";
        int select;
        cin >> select;
        
        //=============================================================
        if (select == 1) // enter a new address into tree
        {
            // variable declarations
            string houseNum;
            string street;
            string streetType; // for part of address that's st. ave. etc
            string city;
            string state;
            string zip;
            
            // Outputs instructions and gets input
            cout << "Enter address info, no spaces for each thing if it's more than 1 word excpt for street and its road type" << endl;
            cout << "Enter House number: ";     cin >> houseNum;
            cout << "\nEnter Street name w/st. ave. etc: ";    cin >> street; cin >> streetType; 
            cout << "\nEnter City: ";           cin >> city;
            cout << "\nEnter State: ";          cin >> state;
            cout << "\nEnter Zip code: ";       cin >> zip;
            
            // combine similarly to read function above
            string key = city + " " + street + " " + streetType;
            string address = houseNum + " " + street  + " " + streetType + " " +  city  + " " + state  + " " + zip;
            
            // call insert method
            Tree.Insert(key, address);
        }
        
        //==============================================================
        else if (select == 2) // Search for address using key (city + street)
        {
            // declare variables
            string addressInput;
            string fullKey;
            
            // User can input the entire address with spaces and has to end with a space and a /
            // While loop continues to add to 'fullKey' until it sees '/' and then which it will break saving everything before the '/'
            cout << "Enter City and Street name and then end it with a space followed by / (ex. 'city street /') (Space, character, and case sensitive): ";
            cin >> addressInput;
            fullKey = addressInput;
            cin >> addressInput;
            while (true)
            {
                fullKey = fullKey + " " + addressInput;
                cin >> addressInput;
                if (addressInput == "/")
                    break;
            }
            
            // call method to search for matching key
            string value;
            if (Tree.Search(fullKey, value))
                cout << "Found address: " << value << endl;
            else 
                cout << "Address not found" << endl;
        }
        
        //================================================================
        else if (select == 3) // Find height with method
        {
            cout << "Height of the tree is currently: " << Tree.height() << endl;
        }
        
        //================================================================
        else // quit
        {
            break;
        }
    }
    
    // final write in sorted address file so it includes any addresses added after the initial read
    Write(sortedFile, Tree);
    
    return 0;
}
