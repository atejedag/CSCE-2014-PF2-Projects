#include "tree.h"
#include <stdlib.h>

// binary tree class from class website source code

//-----------------------------------------------------------
// Constructor function.
//-----------------------------------------------------------
BinaryTree::BinaryTree()
{
   Root = NULL;
}

//-----------------------------------------------------------
// Copy constructor helper function.
//-----------------------------------------------------------
void BinaryTree::CopyHelper(Node * Tree1, Node * &Tree2)
{
   // Check terminating condition
   if (Tree1 == NULL)
      Tree2 = NULL;

   // Copy node and it's children
   else
   {
      Tree2 = new Node;
      Tree2->Value = Tree1->Value;
      Tree2->Key = Tree1->Key;
      CopyHelper(Tree1->Left, Tree2->Left);
      CopyHelper(Tree1->Right, Tree2->Right);
   }
}

//-----------------------------------------------------------
// Copy constructor.
//-----------------------------------------------------------
BinaryTree::BinaryTree(const BinaryTree & B)
{
   // Call tree copy function
   CopyHelper(B.Root, Root);
}

//-----------------------------------------------------------
// Destructor function helper function.
//-----------------------------------------------------------
void BinaryTree::DestroyHelper(Node * Tree)
{
   // Delete node and it's children
   if (Tree != NULL)
   {
      DestroyHelper(Tree->Left);
      DestroyHelper(Tree->Right);
      delete Tree;
   }
}

//-----------------------------------------------------------
// Destructor function.
//-----------------------------------------------------------
BinaryTree::~BinaryTree()
{
   // Call tree destroy function
   DestroyHelper(Root);
}

//-----------------------------------------------------------
// Search helper function.
//-----------------------------------------------------------
bool BinaryTree::SearchHelper(string key, string &value, Node * Tree)
{
   // Data value not found 
   if (Tree == NULL)
      return false;

   // Data value found 
   else if (Tree->Key == key)
   {
      value = Tree->Value;
      return true;
   }

   // Recursively search for data value
   else if (Tree->Key > key)
      return (SearchHelper(key, value, Tree->Left));
   else if (Tree->Key < key)
      return (SearchHelper(key, value, Tree->Right));
   else
      return false;
}

//-----------------------------------------------------------
// Search for data in the binary tree.
//-----------------------------------------------------------
bool BinaryTree::Search(string key, string &value)
{
   // Call tree searching function
   return (SearchHelper(key, value, Root));
}

//-----------------------------------------------------------
// Insert helper function.
//-----------------------------------------------------------
bool BinaryTree::InsertHelper(string key, string value, Node * &Tree)
{
   // Insert key and value into the tree
   if (Tree == NULL)
   {
      Tree = new Node;
      Tree->Key = key;
      Tree->Value = value;
      Tree->Left = NULL;
      Tree->Right = NULL;
      return true;
   }

   // Update value if key found
   else if (Tree->Key == key)
   {
      Tree->Value = value;
      return true;
   }

   // Recursively search for insertion position
   else if (Tree->Key > key)
      return (InsertHelper(key, value, Tree->Left));
   else if (Tree->Key <= key)
      return (InsertHelper(key, value, Tree->Right));
   else
      return false;
}

//-----------------------------------------------------------
// Insert data into the binary tree.
//-----------------------------------------------------------
bool BinaryTree::Insert(string key, string value)
{
   // Call tree insertion function
   return (InsertHelper(key, value, Root));
}

//-----------------------------------------------------------
// Print helper function.
//-----------------------------------------------------------
void BinaryTree::PrintHelper(Node * Tree)
{
   // Check terminating condition
   if (Tree != NULL)
   {
      // Print left subtree
      PrintHelper(Tree->Left);

      // Print node value
      cout << Tree->Key << "," << Tree->Value << "\n";

      // Print right subtree
      PrintHelper(Tree->Right);
   }
}

//-----------------------------------------------------------
// Print all records in the binary tree.
//-----------------------------------------------------------
void BinaryTree::Print()
{
   // Call tree printing function
   PrintHelper(Root);
   cout << endl;
}

//-----------------------------------------------------------
// Print helper function.
//-----------------------------------------------------------
void BinaryTree::PrintHelper(Node * Tree, ofstream & dout)
{
   // Check terminating condition
   if (Tree != NULL)
   {
      // Print left subtree
      PrintHelper(Tree->Left, dout);

      // Print node value
      dout << Tree->Key << ", " << Tree->Value << endl;

      // Print right subtree
      PrintHelper(Tree->Right, dout);
   }
}

//-----------------------------------------------------------
// Print all records in the binary tree.
//-----------------------------------------------------------
void BinaryTree::Print(ofstream & dout)
{
   // Call tree printing function
   PrintHelper(Root, dout);
   dout << endl;
}

// helper method for the height method, finds height of tree
int BinaryTree::heightHelper(Node * Tree)
{
    if (Tree == NULL)
        return 0;

    else
    {
        int left;
        int right;
        
        left = heightHelper(Tree->Left);
        right = heightHelper(Tree->Right);
        
        if (left > right)
            return left + 1;
        else
            return right + 1;
    }
}

// Method to find height of the tree
int BinaryTree::height()
{
    return heightHelper(Root);
}






















