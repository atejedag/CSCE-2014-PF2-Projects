//-----------------------------------------------------------
//  Purpose:    Header file for the BinaryTree class.
//  Author:     John Gauch
//-----------------------------------------------------------

#include <iostream>
#include <fstream>
using namespace std;

//-----------------------------------------------------------
// BinaryTree data node definition
//-----------------------------------------------------------
class Node
{
 public:
   string Key;
   string Value;
   Node *Left;
   Node *Right;
};

//-----------------------------------------------------------
// Define the BinaryTree class interface 
//-----------------------------------------------------------
class BinaryTree
{
 public:
   // Constructor functions
   BinaryTree();
   BinaryTree(const BinaryTree & tree);
    ~BinaryTree();

   // General binary tree operations
   bool Search(string key, string &value);
   bool Insert(string key, string value);
   void Print();
   void Print(ofstream & dout);
   int height();

 private:
   // Helper functions
   void CopyHelper(Node * Tree1, Node * &Tree2);
   void DestroyHelper(Node * Tree);
   bool SearchHelper(string key, string &value, Node * Tree);
   bool InsertHelper(string key, string value, Node * &Tree);
   void PrintHelper(Node * Tree);
   void PrintHelper(Node * Tree, ofstream & dout);
   int heightHelper(Node * Tree);

   // Tree pointer
   Node *Root;
};