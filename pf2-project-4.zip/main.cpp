#include <iostream>
#include <fstream>
#include "stack.h"
using namespace std;

// reading html looked at source code for reference/basic layout


int main()
{
    Stack s; // declare stack object
    
    // open files for input/output
    ifstream din;
    din.open("sampleHTML.txt");
    if (din.fail()) return -1;
    
    ofstream dout;
    dout.open("outputHTML.txt");
    
    
    // main while loop to read, so far only prints out all tags
    bool skip; // check to skip din.get at bottom of while loop
    bool inside = false; // check if reading inside of tag <...>
    char ch = din.get();
    string tag = "";
    string poppedTag;
    string noSlashTag;
    
    // MAIN while loop    
    while (ch != EOF) 
    {
        skip = false; // reset for din.get if statement at bottom of main loop
        if (ch == '<')
        {
            inside = true; // will read/cout if inside <...>
        }
        else if (ch == '>') // end of reading tag, stops
        {
            inside = false; // stop saving char. after this
            if (tag[0] != '/') // checks for slash to push said tag
            {
                if (tag != "br" && tag != "hr" && tag != "meta" && tag != "input" && tag != "img") // don't push singular tags that dont pair
                {
                    s.Push(tag); 
                    dout << "<" << tag << ">" << endl; // write tag to output file
                    cout << "Pushed <" << tag << ">" << endl;
                }
            }
            else // Time to pop if tag with slash
            {
                dout << "<" << tag << ">" << endl;
                if (tag != "/br" && tag != "/hr" && tag != "/meta" && tag != "/input" && tag != "/img") // No popping if /tag is one of these
                {
                    noSlashTag = "";  // reset string to get tag without slash
                    for (int i = 1; i < tag.size(); i++) // go through tag and duplicate it without / in beginning
                    {
                        noSlashTag = noSlashTag + tag[i];
                    }
                    
                    s.Pop(poppedTag); // pop tag on top of stack
                    if (poppedTag != noSlashTag) // compare to current tag, if not the same output on screen, then close files and stop program
                    {
                        cout << "MISSMATCHED TAGS <" << poppedTag << "> and <" << noSlashTag << ">" << endl;
                        din.close();
                        dout.close();
                        return 0;
                    }
                    else // if tags match 
                    {
                        cout << endl << "<" << tag << ">" << endl;
                        cout << "Popped <" << poppedTag << ">" << endl << endl;
                    }
                }
            }
            
            tag = ""; // reset tag
            noSlashTag = "";
        }
        
        if (inside == true) // to cout if inside <...>
        {
            if (ch != ' ') // if not space then save char.
            {
                if (ch != '<')
                    tag = tag + ch;
            }
            else if (ch == ' ') // if it's a space, skip rest of stuff inside
            {
                ch = din.get();
                while (ch != '>') // skips until reads '>''
                {
                    ch = din.get();
                }                
    
                // used to skip last din.get of while loop otherwise it will mess up
                skip = true; 
            }
        }
        if (skip == false)
        {
            ch = din.get();
        }
        
    }
    
    if (s.IsEmpty())
    {
        cout << "NO MISSMATCHED TAGS" << endl;
    }
    
    //close in/out files
    din.close();
    dout.close();
    return 0;
}
