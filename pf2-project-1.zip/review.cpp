#include "review.h"

review::review()
{
    // construcc
    reviewerName = " ";
    restaurant = " ";
    category = " ";
    cost = 0;
    rating = 0;
}


review::review(const review & copy)
{
    // copy construcc
    reviewerName = copy.reviewerName;
    restaurant = copy.restaurant;
    category = copy.category;
    cost = copy.cost;
    rating = copy.rating;
}



review::~review()
{
    // destrucc
}

//--------------------------------------------
//                  Setters                 
//--------------------------------------------
void review::setreviewerName()
{
    cout << "Input the reviewer name" << endl;
    cin >> reviewerName;
}


void review::setRestaurant()
{
    cout << "Input the restaurant name" << endl;
    cin >> restaurant;
}


void review::setCategory()
{
    cout << "Input the category" << endl;
    cin >> category;
}


void review::setCost()
{
    cout << "Input the delivery cost" << endl;
    cin >> cost;
}


void review::setRating()
{
    cout << "Input the rating, 1-10" << endl;
    cin >> rating;
    while (rating > 10 || rating < 1)
    {
        cout << "Not in range, input rating again" << endl;
        cin >> rating;
    }
    
}

//--------------------------------------------
//                  Getters                 
//--------------------------------------------
string review::getreviewerName()
{
    return reviewerName;
}


string review::getRestaurant()
{
    return restaurant;
}


string review::getCategory()
{
    return category;
}


float review::getCost()
{
    return cost;
}


int review::getRating()
{
    return rating;
}

//--------------------------------------------
//                  Other                 
//--------------------------------------------
void review::printReview() // prints all review information
{
    cout << endl;
    cout << "Reviewer Name: " << reviewerName << endl;
    cout << "Restaurant: " << restaurant << endl;
    cout << "Category: " << category << endl;
    cout << "Delivery cost: " << cost << endl;
    cout << "Rating: " << rating << "/10" << endl; 
    cout << endl;
}
















