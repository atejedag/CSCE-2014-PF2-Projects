#include <iostream>
#include "review.h"
using namespace std;

const int SIZE = 100;

class reviewDB
{
public:
    // construcc
    reviewDB();
    reviewDB(const reviewDB & copy);
    ~reviewDB();
    
    // methods, to add paremeters possibly
    void insertReview(); // new review to end of array and increment count
    void printRestaurant(); // prints all reviews for restaurant
    void printCategory(); // prints all reviews for printCategory
    void printRecent(); // prints N most recent reviews
    
    int getCount();
    
private:
    int count;
    review reviewArray[SIZE];
};