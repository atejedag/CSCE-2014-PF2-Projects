#include <iostream>
using namespace std;

class review
{
public:
    //construcc
    review();
    review(const review & copy);
    ~review();
    
    // setters
    void setreviewerName();
    void setRestaurant();
    void setCategory();
    void setCost();
    void setRating();
    
    // getters
    string getreviewerName();
    string getRestaurant();
    string getCategory();
    float  getCost();
    int    getRating();
    
    // other
    void printReview();
    
private:
    string reviewerName;
    string restaurant;
    string category;
    float cost; // delivery cost
    int rating; //1-10
};