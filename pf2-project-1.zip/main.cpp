#include <iostream>
#include "reviewDB.h"
using namespace std;

int main()
{
    reviewDB reviewDB;
    bool QUIT = false;
    
    cout << "Review Database class" << endl;
    int select; // variable to store int that user inputs to decide what thing to call
    
    while (QUIT == false)
    {
        
        cout << endl << "Current amount of items in array = " << reviewDB.getCount() << endl << endl;
        
        cout << "Choose what you want to do by typing the corresponding numbers" << endl;
        cout << "[1]Create and insert a review into the array" << endl;
        cout << "[2]Print out all reviews from a specific restaurant" << endl;
        cout << "[3]Print out all reviews from a specific category" << endl;
        cout << "[4]Print out the Nth most recent reviews" << endl;
        cout << "[5]QUIT the program (any other number out of the range will also quit the program)" << endl;
        
        cin >> select;
        cout << endl;
        
        
        
        if (select == 1) reviewDB.insertReview();
        
        else if (select == 2) reviewDB.printRestaurant();
        
        else if (select == 3) reviewDB.printCategory();
        
        else if (select == 4) reviewDB.printRecent();
        
        else 
        {
            cout << "Quitting..." << endl;
            QUIT = true;
        }
        
        
    }
    
    return 0;
}
