#include "reviewDB.h"

reviewDB::reviewDB()
{
    // Construcc
    count = 0;
}

reviewDB::reviewDB(const reviewDB & copy)
{
    // add code to copy stuff
    
    
}

reviewDB::~reviewDB()
{
    // destrucc
    
    
}





int reviewDB::getCount()
{
    return count;
}



void reviewDB::insertReview()
{
    // code to insert review into array
    reviewArray[count].setreviewerName();
    reviewArray[count].setRestaurant();
    reviewArray[count].setCategory();
    reviewArray[count].setCost();
    reviewArray[count].setRating();
    
    count = count + 1;
    cout << "Total reviews: " << count << endl;
}



void reviewDB::printRestaurant()
{
    // code to print out all restaurant reviews
    if (count > 0) // skips if array is empty
    {
        int reviewsFound = 0; // record number of reviews found
        string inputRestaurant; // store input for restuarant
        string foundRestaurant; // temp store restaurant name
        cout << "Input name of restaurant (case sensitive)" << endl;
        cin >> inputRestaurant;
        
        for (int i = 0; i < count; i = i + 1) // forloop to go through entire array
        {
            foundRestaurant = reviewArray[i].getRestaurant();
            
            if (foundRestaurant == inputRestaurant)
            {
                reviewsFound = reviewsFound + 1;
                reviewArray[i].printReview();
            }
            
        }
        
        if (reviewsFound == 0) // no reviews found under input
        {
            cout << "No reviews found under restaurant name '" << inputRestaurant << "'" << endl;
        }
        
        
    }
    
    else
    {
        cout << "Array is empty, no reviews" << endl;
    }
    
}



void reviewDB::printCategory()
{
    // code to print all category reviews
    if (count > 0) // skips if array is empty
    {
        int reviewsFound = 0; // record number of reviews found
        string inputCategory; // store input for category
        string foundCategory; // temp store restaurant name
        cout << "Input name of category (Case sensitive)" << endl;
        cin >> inputCategory;
        
        for (int i = 0; i < count; i = i + 1) // forloop to go through entire array
        {
            foundCategory = reviewArray[i].getCategory();
            
            if (foundCategory == inputCategory)
            {
                reviewsFound = reviewsFound + 1;
                reviewArray[i].printReview();
            }
            
        }
        
        if (reviewsFound == 0) // no reviews found under input
        {
            cout << "No reviews found under category name '" << inputCategory << "'" << endl;
        }
        
        
    }
    
    else
    {
        cout << "Array is empty, no reviews" << endl;
    }
    
}


void reviewDB::printRecent()
{
    // code to print N most recent reviews
    if (count > 1)
    {
        int N;
        cout << "Input the Nth most recent reviews to be printed out" << endl;
        cin >> N;
        while ((N > count) || (N < 1)) // while loop to check if N is in range
        {
            cout << "Input not in range, input again" << endl;
            cin >> N;
        }
        
        
        int tempCount = count - N; // setup to get backwards forloop
        
        for (int i = count - 1; i >= tempCount; i = i - 1)
        {
            reviewArray[i].printReview();
        }
    }
    else if (count == 1)
    {
        cout << "Only 1 item in array so will print that one item" << endl;
        reviewArray[0].printReview();
    }
    else if (count == 0)
    {
        cout << "No items in array" << endl;
    }
    
}
